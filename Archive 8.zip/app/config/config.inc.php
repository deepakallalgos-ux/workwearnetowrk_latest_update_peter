<?php
if (!defined("PJ_HOST")) define("PJ_HOST", "localhost");
if (!defined("PJ_USER")) define("PJ_USER", "root");
if (!defined("PJ_PASS")) define("PJ_PASS", "");
if (!defined("PJ_DB")) define("PJ_DB", "workwearnetwork");
if (!defined("PJ_PREFIX")) define("PJ_PREFIX", "");
if (!defined("PJ_INSTALL_FOLDER")) define("PJ_INSTALL_FOLDER", "/workwearnetwork/");
if (!defined("PJ_INSTALL_PATH")) define("PJ_INSTALL_PATH", "/Applications/XAMPP/xamppfiles/htdocs/workwearnetwork/");
if (!defined("PJ_INSTALL_URL")) define("PJ_INSTALL_URL", "http://localhost/workwearnetwork/");
if (!defined("PJ_SALT")) define("PJ_SALT", "ZRBE0XO8");
if (!defined("PJ_INSTALLATION")) define("PJ_INSTALLATION", "aafa86cd42246249a2c6195b3b294ca8");
?>