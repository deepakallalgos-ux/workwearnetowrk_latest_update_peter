<?php
if (!defined("ROOT_PATH")) {
	header("HTTP/1.1 403 Forbidden");
	exit;
}
class pjAdmin extends pjAppController
{
	public $defaultUser = 'admin_user';
	public $defaultCompany = 'admin_selected_company';
	public $requireLogin = true;

	public function __construct($requireLogin = null)
	{
		$this->setLayout('pjActionAdmin');

		if (!is_null($requireLogin) && is_bool($requireLogin)) {
			$this->requireLogin = $requireLogin;
		}

		if ($this->requireLogin) {
			if (!$this->isLoged() && !in_array(@$_REQUEST['action'], array('pjActionLogin', 'pjActionForgot', 'pjActionPreview', 'pjActionExportFeed'))) {
				if (!$this->isXHR()) {
					pjUtil::redirect($_SERVER['PHP_SELF'] . "?controller=pjBase&action=pjActionLogin");
				} else {
					header('HTTP/1.1 401 Unauthorized');
					exit;
				}
			}
		}

		$ref_inherits_arr = array();
		if ($this->isXHR() && isset($_SERVER['HTTP_REFERER'])) {
			$http_refer_arr = parse_url($_SERVER['HTTP_REFERER']);
			parse_str($http_refer_arr['query'], $arr);
			if (isset($arr['controller']) && isset($arr['action'])) {
				parse_str($_SERVER['QUERY_STRING'], $query_string_arr);
				$key = $query_string_arr['controller'] . '_' . $query_string_arr['action'];
				$cnt = pjAuthPermissionModel::factory()->where('`key`', $key)->findCount()->getData();
				if ($cnt <= 0) {
					$ref_inherits_arr[$query_string_arr['controller'] . '::' . $query_string_arr['action']] = $arr['controller'] . '::' . $arr['action'];
				}
			}
		}
		$inherits_arr = array(
			'pjAdminOptions::pjActionUpdateTheme' => 'pjAdminOptions::pjActionPreview',
			'pjBasePermissions::pjActionResetPermission' => 'pjBasePermissions::pjActionUserPermission',
			'pjAdminOptions::pjActionDeleteLocation' => 'pjAdminOptions::pjActionShippingTax',
			'pjAdminCategories::pjActionGetCategory' => 'pjAdminCategories::pjActionIndex',
			'pjAdminCategories::pjActionCreate' => 'pjAdminCategories::pjActionCreateForm',
			'pjAdminCategories::pjActionUpdate' => 'pjAdminCategories::pjActionUpdateForm',
			'pjAdminCategories::pjActionSaveCategory' => 'pjAdminCategories::pjActionUpdateForm',
			'pjAdminCategories::pjActionSetOrder' => 'pjAdminCategories::pjActionUpdateForm',
			'pjAdminProducts::pjActionCheckStockAttributes' => 'pjAdminProducts::pjActionUpdate'

		);
		if ($_REQUEST['controller'] == 'pjAdminOptions' && isset($_REQUEST['next_action'])) {
			$inherits_arr['pjAdminOptions::pjActionUpdate'] = 'pjAdminOptions::' . $_REQUEST['next_action'];
		}
		$inherits_arr = array_merge($inherits_arr, $ref_inherits_arr);
		pjRegistry::getInstance()->set('inherits', $inherits_arr);
	}

	public function beforeFilter()
	{
		parent::beforeFilter();

		if (!pjAuth::factory()->hasAccess() && @$_REQUEST['action'] != 'pjActionExportFeed') {
			$this->sendForbidden();
			return false;
		}

		return true;
	}

	public function afterFilter()
	{
		parent::afterFilter();
		$this->appendJs('index.php?controller=pjBase&action=pjActionMessages', PJ_INSTALL_URL, true);
	}

	public function beforeRender() {}


	public function pjActionIndex()
	{
		$this->checkLogin();
		if (!pjAuth::factory()->hasAccess()) {
			$this->sendForbidden();
			return;
		}

		/* ================= COMPANY ID ================= */
		$company_id = 0;
		if (isset($_SESSION[$this->defaultCompany]['id']) && (int)$_SESSION[$this->defaultCompany]['id'] > 0) {
			$company_id = (int)$_SESSION[$this->defaultCompany]['id'];
		} else {
			$company_id = (int)$this->getForeignId();
		}
		/* ============================================== */

		/* ================= MODELS ================= */
		$pjOrderModel       = pjOrderModel::factory();
		$pjOrderStockModel  = pjOrderStockModel::factory();
		$pjProductModel     = pjProductModel::factory();
		$pjClientModel      = pjClientModel::factory();
		$pjVoucherModel     = pjVoucherModel::factory();
		/* =========================================== */

		/* ================= TODAY STATS (ZERO SAFE) ================= */
		$info_arr = pjAppModel::factory()
			->prepare(sprintf(
				"SELECT 1,
            COALESCE((
                SELECT COUNT(*)
                FROM `%1\$s`
                WHERE DATE(`created`) = CURDATE()
                  AND company_id = %2\$d
            ),0) AS `orders`,

            COALESCE((
                SELECT SUM(`total`)
                FROM `%1\$s`
                WHERE DATE(`created`) = CURDATE()
                  AND company_id = %2\$d
            ),0) AS `amount`,

            COALESCE((
                SELECT COUNT(DISTINCT product_id)
                FROM `%3\$s`
                WHERE order_id IN (
                    SELECT id
                    FROM `%1\$s`
                    WHERE DATE(`created`) = CURDATE()
                      AND company_id = %2\$d
                )
            ),0) AS `products`",
				$pjOrderModel->getTable(),
				$company_id,
				$pjOrderStockModel->getTable()
			))
			->exec()
			->getData();
		/* ========================================================== */

		/* ================= TOTAL ORDERS ================= */
		$cnt_orders = $pjOrderModel->reset()
			->where('status <>', 'cancelled')
			->where('company_id', $company_id)
			->findCount()
			->getData();
		/* ================================================= */

		/* ================= TOTAL AMOUNT ================= */
		$amount = $pjOrderModel->reset()
			->select("COALESCE(SUM(total),0) AS amount")
			->where('status <>', 'cancelled')
			->where('company_id', $company_id)
			->findAll()
			->getData();
		/* ================================================= */

		/* ================= LATEST ORDERS ================= */
		$order_arr = $pjOrderModel->reset()
			->select("t1.*, t2.client_name")
			->join("pjClient", "t1.client_id=t2.id", "left outer")
			->where('t1.company_id', $company_id)
			->orderBy('t1.created DESC')
			->limit(6)
			->findAll()
			->getData();
		/* ================================================= */

		/* ================= PRODUCTS ORDERED TODAY ================= */
		$product_arr = array();

		$product_ordered_arr = $pjOrderStockModel->reset()
			->select("t1.product_id, t2.id AS order_id, t2.uuid, t3.content AS name")
			->join("pjOrder", "t1.order_id=t2.id", "left outer")
			->join(
				"pjMultiLang",
				"t3.model='pjProduct'
             AND t3.foreign_id=t1.product_id
             AND t3.locale='" . $this->getLocaleId() . "'
             AND t3.field='name'",
				"left outer"
			)
			->where("DATE(t2.created) = CURDATE()")
			->where("t1.company_id", $company_id)
			->orderBy("t2.created DESC")
			->findAll()
			->getData();

		foreach ($product_ordered_arr as $v) {
			$product_arr[$v['product_id']][] = $v;
			if (count($product_arr) >= 5) {
				break;
			}
		}
		/* =========================================================== */

		/* ================= VOUCHERS ================= */
		$voucher_arr = $pjVoucherModel
			->where('company_id', $company_id)
			->findAll()
			->getData();
		/* ================================================= */

		/* ================= SET VIEW VARS ================= */
		$this
			->set('info_arr', $info_arr)
			->set('cnt_orders', (int)$cnt_orders)
			->set('amount', !empty($amount) ? $amount[0]['amount'] : 0)
			->set('order_arr', $order_arr)
			->set('product_arr', $product_arr)
			->set('voucher_arr', $voucher_arr);
		/* ================================================= */

		/* ================= PAYMENTS ================= */
		if (pjObject::getPlugin('pjPayments') !== NULL) {
			$this->set(
				'payment_option_arr',
				pjPaymentOptionModel::factory()->getOptions($company_id)
			);
			$this->set(
				'payment_titles',
				pjPayments::getPaymentTitles($company_id, $this->getLocaleId())
			);
		} else {
			$this->set('payment_titles', __('payment_methods', true));
		}
		/* ================================================= */
	}
}
