<?php
if (!defined("ROOT_PATH")) {
	header("HTTP/1.1 403 Forbidden");
	exit;
}
class pjAppController extends pjBaseAppController
{
	public $models = array();

	public function pjActionCheckInstall()
	{
		$this->setLayout('pjActionEmpty');

		$result = array('status' => 'OK', 'code' => 200, 'text' => 'Operation succeeded', 'info' => array());
		$folders = array(
			'app/web/upload/digital',
			'app/web/upload/large',
			'app/web/upload/locale',
			'app/web/upload/medium',
			'app/web/upload/small',
			'app/web/upload/source'
		);
		foreach ($folders as $dir) {
			if (!is_writable($dir)) {
				$result['status'] = 'ERR';
				$result['code'] = 101;
				$result['text'] = 'Permission requirement';
				$result['info'][] = sprintf('Folder \'<span class="bold">%1$s</span>\' is not writable. You need to set write permissions (chmod 777) to directory located at \'<span class="bold">%1$s</span>\'', $dir);
			}
		}

		return $result;
	}

	/**
	 * Sets some predefined role permissions and grants full permissions to Admin.
	 */
	public function pjActionAfterInstall()
	{
		$this->setLayout('pjActionEmpty');

		$result = array('status' => 'OK', 'code' => 200, 'text' => 'Operation succeeded', 'info' => array());

		$pjAuthRolePermissionModel = pjAuthRolePermissionModel::factory();
		$pjAuthUserPermissionModel = pjAuthUserPermissionModel::factory();

		$permissions = pjAuthPermissionModel::factory()->findAll()->getDataPair('key', 'id');

		$roles = array(1 => 'admin', 2 => 'editor');
		foreach ($roles as $role_id => $role) {
			if (
				isset($GLOBALS['CONFIG'], $GLOBALS['CONFIG']["role_permissions_{$role}"])
				&& is_array($GLOBALS['CONFIG']["role_permissions_{$role}"])
				&& !empty($GLOBALS['CONFIG']["role_permissions_{$role}"])
			) {
				$pjAuthRolePermissionModel->reset()->where('role_id', $role_id)->eraseAll();

				foreach ($GLOBALS['CONFIG']["role_permissions_{$role}"] as $role_permission) {
					if ($role_permission == '*') {
						// Grant full permissions for the role
						foreach ($permissions as $key => $permission_id) {
							$pjAuthRolePermissionModel->setAttributes(compact('role_id', 'permission_id'))->insert();
						}
						break;
					} else {
						$hasAsterix = strpos($role_permission, '*') !== false;
						if ($hasAsterix) {
							$role_permission = str_replace('*', '', $role_permission);
						}

						foreach ($permissions as $key => $permission_id) {
							if ($role_permission == $key || ($hasAsterix && strpos($key, $role_permission) !== false)) {
								$pjAuthRolePermissionModel->setAttributes(compact('role_id', 'permission_id'))->insert();
							}
						}
					}
				}
			}
		}

		pjOptionModel::factory()
			->where('company_id', 1)
			->where('`key`', 'o_install_url')
			->modifyAll(array(
				'value' => PJ_INSTALL_URL . 'preview.php'
			));

		// Grant full permissions to Admin
		$user_id = 1; // Admin ID
		$pjAuthUserPermissionModel->reset()->where('user_id', $user_id)->eraseAll();
		foreach ($permissions as $key => $permission_id) {
			$pjAuthUserPermissionModel->setAttributes(compact('user_id', 'permission_id'))->insert();
		}

		return $result;
	}

	public function isEditor()
	{
		return $this->getRoleId() == 2;
	}

	public function getForeignId()
	{
		return 1;
	}

	public function beforeFilter()
	{
		parent::beforeFilter();

		if (!in_array($this->_get->toString('controller'), array('pjFront', 'pjInstaller'))) {
			$this->appendJs('pjAdminCore.js');
			$this->appendCss('admin.css');

			if (in_array($this->_get->toString('controller'), array('pjAdminProducts')) && in_array($this->_get->toString('action'), array('pjActionUpdate'))) {
				$this->appendCss('pj-all.css', PJ_FRAMEWORK_LIBS_PATH . 'pj/css/');
				$this->appendJs('jquery-ui.min.js', PJ_THIRD_PARTY_PATH . 'jquery_ui/');
				$this->appendCss('jquery-ui.min.css', PJ_THIRD_PARTY_PATH . 'jquery_ui/');
			}
		}
		return true;
	}

	public static function jsonDecode($str)
	{
		$Services_JSON = new pjServices_JSON();
		return $Services_JSON->decode($str);
	}

	public static function jsonEncode($arr)
	{
		$Services_JSON = new pjServices_JSON();
		return $Services_JSON->encode($arr);
	}

	public static function jsonResponse($arr)
	{
		header("Content-Type: application/json; charset=utf-8");
		echo pjAppController::jsonEncode($arr);
		exit;
	}

	public function getLocaleId()
	{
		return isset($_SESSION[$this->defaultLocale]) && (int) $_SESSION[$this->defaultLocale] > 0 ? (int) $_SESSION[$this->defaultLocale] : false;
	}

	public function setLocaleId($locale_id)
	{
		$_SESSION[$this->defaultLocale] = (int) $locale_id;
	}

	static public function getFromEmail()
	{
		$arr = pjAuthUserModel::factory()
			->findAll()
			->orderBy("t1.id ASC")
			->limit(1)
			->getData();
		return !empty($arr) ? $arr[0]['email'] : null;
	}

	static public function getAdminEmail()
	{
		$arr = pjAuthUserModel::factory()
			->where('t1.role_id', '1')
			->where('t1.status', 'T')
			->findAll()
			->getDataPair('id', 'email');
		return $arr;
	}

	static public function getAdminPhone()
	{
		$arr = pjAuthUserModel::factory()
			->where('t1.role_id', '1')
			->where('t1.status', 'T')
			->findAll()
			->getDataPair('id', 'phone');
		return $arr;
	}

	public function friendlyURL($str, $divider = '-')
	{
		$str = mb_strtolower($str, mb_detect_encoding($str));
		$str = trim($str);
		$str = preg_replace('/[_|\s]+/', $divider, $str);
		$str = preg_replace('/\x{00C5}/u', 'AA', $str);
		$str = preg_replace('/\x{00C6}/u', 'AE', $str);
		$str = preg_replace('/\x{00D8}/u', 'OE', $str);
		$str = preg_replace('/\x{00E5}/u', 'aa', $str);
		$str = preg_replace('/\x{00E6}/u', 'ae', $str);
		$str = preg_replace('/\x{00F8}/u', 'oe', $str);
		$str = preg_replace('/[^a-z\x{0400}-\x{04FF}0-9-]+/u', '', $str);
		$str = preg_replace('/[-]+/', $divider, $str);
		$str = preg_replace('/^-+|-+$/', '', $str);
		return $str;
	}

	public static function getSubjectMessage($notification, $locale_id)
	{
		$variant = $notification['variant'] == 'confirmation' ? 'confirm' : $notification['variant'];
		$field = $variant . '_tokens_' . $notification['recipient'];
		$pjMultiLangModel = pjMultiLangModel::factory();
		$lang_message = $pjMultiLangModel
			->reset()
			->select('t1.*')
			->where('t1.foreign_id', $notification['id'])
			->where('t1.model', 'pjNotification')
			->where('t1.locale', $locale_id)
			->where('t1.field', $field)
			->limit(0, 1)
			->findAll()
			->getData();
		$field = $variant . '_subject_' . $notification['recipient'];
		$lang_subject = $pjMultiLangModel
			->reset()
			->select('t1.*')
			->where('t1.foreign_id',  $notification['id'])
			->where('t1.model', 'pjNotification')
			->where('t1.locale', $locale_id)
			->where('t1.field', $field)
			->limit(0, 1)
			->findAll()
			->getData();
		return compact('lang_message', 'lang_subject');
	}

	public static function getSmsMessage($notification, $locale_id)
	{
		$variant = $notification['variant'] == 'confirmation' ? 'confirm' : $notification['variant'];
		$field = $variant . '_sms_' . $notification['recipient'];
		$pjMultiLangModel = pjMultiLangModel::factory();
		$lang_message = $pjMultiLangModel
			->reset()
			->select('t1.*')
			->where('t1.foreign_id', $notification['id'])
			->where('t1.model', 'pjNotification')
			->where('t1.locale', $locale_id)
			->where('t1.field', $field)
			->limit(0, 1)
			->findAll()
			->getData();
		return compact('lang_message');
	}

	public static function getDiscount($data, $option_arr)
	{
		if (!isset($data['code']) || empty($data['code'])) {
			// Missing params
			return array('status' => 'ERR', 'code' => 100, 'text' => __('system_134', true));
		}


		$pjVoucherModel = pjVoucherModel::factory();
		$pjVoucherModel::factory()
			->select(sprintf("t1.*, (SELECT GROUP_CONCAT(`product_id`) FROM `%s` WHERE `voucher_id` = `t1`.`id` LIMIT 1) AS `products`", pjVoucherProductModel::factory()->getTable()))
			->where('t1.code', $data['code']);
		// ✔ Add company filter only if valid
		if (isset($data['company_id']) && $data['company_id'] !== '') {
			$pjVoucherModel->where('t1.company_id', $data['company_id']);
		}
		$arr = $pjVoucherModel->findAll()
			->limit(1)
			->toArray('products', ',')
			->getData();

		if (empty($arr)) {
			// Not found
			return array('status' => 'ERR', 'code' => 101, 'text' => __('system_133', true));
		}
		$arr = $arr[0];

		$date = $data['date'];
		if (isset($data['hour']) && isset($data['minute'])) {
			$time = $data['hour'] . ":" . $data['minute'] . ":00";
		}
		if (!isset($time)) {
			$time = "00:00:00";
		}
		if (empty($date)) {
			// Empty date
			return array('status' => 'ERR', 'code' => 103, 'text' => __('system_135', true));
		}
		$d = strtotime($date);
		$dt = strtotime($date . " " . $time);

		$valid = false;
		switch ($arr['valid']) {
			case 'fixed':
				$time_from = strtotime($arr['date_from'] . " " . $arr['time_from']);
				$time_to = strtotime($arr['date_to'] . " " . $arr['time_to']);
				if ($time_from <= $dt && $time_to >= $dt) {
					// Valid
					$valid = true;
				}
				break;
			case 'period':
				$d_from = strtotime($arr['date_from']);
				$d_to = strtotime($arr['date_to']);
				$t_from = strtotime($arr['date_from'] . " " . $arr['time_from']);
				$t_to = strtotime($arr['date_to'] . " " . $arr['time_to']);
				if ($d_from <= $d && $d_to >= $d && $t_from <= $dt && $t_to >= $dt) {
					// Valid
					$valid = true;
				}
				break;
			case 'recurring':
				$t_from = strtotime($date . " " . $arr['time_from']);
				$t_to = strtotime($date . " " . $arr['time_to']);
				if ($arr['every'] == strtolower(date("l", $dt)) && $t_from <= $dt && $t_to >= $dt) {
					// Valid
					$valid = true;
				}
				break;
		}

		if (!$valid) {
			// Out of date
			return array('status' => 'ERR', 'code' => 102, 'text' => __('system_136', true));
		}

		// Valid
		return array(
			'status' => 'OK',
			'code' => 200,
			'text' => __('system_137', true),
			'voucher_code' => $arr['code'],
			'voucher_type' => $arr['type'],
			'voucher_apply' => $arr['apply'],
			'voucher_discount' => $arr['discount'],
			'voucher_products' => $arr['products']
		);
	}

	public static function addToHistory($record_id, $user_id, $table, $before, $after)
	{
		return pjHistoryModel::factory()->setAttributes(array(
			'record_id' => $record_id,
			'user_id' => $user_id,
			'table_name' => $table,
			'before' => base64_encode(serialize($before)),
			'after' => base64_encode(serialize($after)),
			'ip' => $_SERVER['REMOTE_ADDR']
		))->insert()->getInsertId();
	}

	public static function getTokens($order_arr, $option_arr)
	{
		$search = array(
			'{BillingName}',
			'{BillingCountry}',
			'{BillingCity}',
			'{BillingState}',
			'{BillingZip}',
			'{BillingAddress1}',
			'{BillingAddress2}',
			'{ShippingName}',
			'{ShippingCountry}',
			'{ShippingCity}',
			'{ShippingState}',
			'{ShippingZip}',
			'{ShippingAddress1}',
			'{ShippingAddress2}',
			'{ClientName}',
			'{ClientEmail}',
			'{ClientPassword}',
			'{ClientPhone}',
			'{ClientURL}',
			'{PaymentMethod}',
			'{Price}',
			'{Discount}',
			'{Insurance}',
			'{Shipping}',
			'{Tax}',
			'{Total}',
			'{Voucher}',
			'{Notes}',
			'{OrderID}',
			'{OrderUUID}',
			'{DigitalDownload}',
			'{Products}',
			'{StoreName}'
		);
		$digital_download = __('front_na', true);
		if ($order_arr['has_digital'] == true) {
			$digital_download = sprintf("%sindex.php?controller=pjFront&action=pjActionDigitalDownload&uuid=%s&hash=%s", PJ_INSTALL_URL, $order_arr['uuid'], md5($order_arr['uuid'] . PJ_SALT));
		}
		$email = isset($order_arr['email']) ? $order_arr['email'] : (isset($order_arr['client_email']) ? $order_arr['client_email'] : NULL);
		$phone = isset($order_arr['phone']) ? $order_arr['phone'] : (isset($order_arr['client_phone']) ? $order_arr['client_phone'] : NULL);
		$url = isset($order_arr['url']) ? $order_arr['url'] : (isset($order_arr['client_url']) ? $order_arr['client_url'] : NULL);
		$replace = array(
			$order_arr['b_name'],
			@$order_arr['b_country'],
			$order_arr['b_city'],
			$order_arr['b_state'],
			$order_arr['b_zip'],
			$order_arr['b_address_1'],
			$order_arr['b_address_2'],
			isset($order_arr['same_as']) && $order_arr['same_as'] == 1 ? $order_arr['b_name'] : $order_arr['s_name'],
			isset($order_arr['same_as']) && $order_arr['same_as'] == 1 ? $order_arr['b_country'] : $order_arr['s_country'],
			isset($order_arr['same_as']) && $order_arr['same_as'] == 1 ? $order_arr['b_city'] : $order_arr['s_city'],
			isset($order_arr['same_as']) && $order_arr['same_as'] == 1 ? $order_arr['b_state'] : $order_arr['s_state'],
			isset($order_arr['same_as']) && $order_arr['same_as'] == 1 ? $order_arr['b_zip'] : $order_arr['s_zip'],
			isset($order_arr['same_as']) && $order_arr['same_as'] == 1 ? $order_arr['b_address_1'] : $order_arr['s_address_1'],
			isset($order_arr['same_as']) && $order_arr['same_as'] == 1 ? $order_arr['s_address_2'] : $order_arr['s_address_2'],
			$order_arr['client_name'],
			$email,
			$order_arr['password'],
			$phone,
			$url,
			$order_arr['payment_method'],
			$order_arr['price'] . " " . $option_arr['o_currency'],
			$order_arr['discount'] . " " . $option_arr['o_currency'],
			$order_arr['insurance'] . " " . $option_arr['o_currency'],
			$order_arr['shipping'] . " " . $option_arr['o_currency'],
			$order_arr['tax'] . " " . $option_arr['o_currency'],
			$order_arr['total'] . " " . $option_arr['o_currency'],
			$order_arr['voucher'],
			$order_arr['notes'],
			$order_arr['id'],
			$order_arr['uuid'],
			$digital_download,
			@$order_arr['products'],
			__('lblStoreName', true)
		);
		return compact('search', 'replace');
	}

	public static function pjActionCheckDigital($order_id)
	{
		$has_digital = false;
		$digitals = array();
		$os_arr = pjOrderStockModel::factory()
			->select('t2.digital_file, t2.digital_name, t2.is_digital')
			->join('pjProduct', "t2.id=t1.product_id AND t2.is_digital='1'", 'inner')
			->where('t1.order_id', $order_id)
			->findAll()
			->getData();
		foreach ($os_arr as $item) {
			$digitals[] = $item;
		}
		foreach ($digitals as $file) {
			if (!empty($file['digital_file']) && is_file($file['digital_file'])) {
				$has_digital = true;
				break;
			}
		}
		return $has_digital;
	}

	public static function pjActionGetExtrasList($product_id, $locale_id)
	{
		$pjExtraItemModel = pjExtraItemModel::factory();
		$pjExtraModel = pjExtraModel::factory();
		if (!empty($product_id)) {
			$pjExtraModel->whereIn('t1.product_id', $product_id);
		}
		$extra_arr = $pjExtraModel
			->select('t1.*, t2.content AS name, t3.content AS title')
			->join('pjMultiLang', "t2.model='pjExtra' AND t2.foreign_id=t1.id AND t2.locale='$locale_id' AND t2.field='extra_name'", 'left outer')
			->join('pjMultiLang', "t3.model='pjExtra' AND t3.foreign_id=t1.id AND t3.locale='$locale_id' AND t3.field='extra_title'", 'left outer')
			->orderBy('`title` ASC, `name` ASC')
			->findAll()
			->getData();


		foreach ($extra_arr as $k => $extra) {
			$extra_arr[$k]['extra_items'] = $pjExtraItemModel
				->reset()
				->select('t1.*, t2.content AS name')
				->join('pjMultiLang', "t2.model='pjExtraItem' AND t2.foreign_id=t1.id AND t2.locale='$locale_id' AND t2.field='extra_name'", 'left outer')
				->where('t1.extra_id', $extra['id'])
				->orderBy('t1.price ASC')
				->findAll()
				->getData();
		}
		return $extra_arr;
	}

	public static function pjActionGetAttr($product_id, $locale_id)
	{
		$attr_arr = $a_arr = array();
		if (!empty($product_id)) {
			// Do not change col_name, direction
			$a_arr = pjAttributeModel::factory()
				->select('t1.id, t1.product_id, t1.parent_id, t2.content AS name')
				->join('pjMultiLang', "t2.model='pjAttribute' AND t2.foreign_id=t1.id AND t2.field='name' AND t2.locale='$locale_id'", 'left outer')
				->whereIn('t1.product_id', $product_id)
				->orderBy('t1.parent_id ASC, `name` ASC')
				->findAll()
				->getData();
		}
		foreach ($a_arr as $attr) {
			if ((int) $attr['parent_id'] === 0) {
				$attr_arr[$attr['id']] = $attr;
			} else {
				if (!isset($attr_arr[$attr['parent_id']]['child'])) {
					$attr_arr[$attr['parent_id']]['child'] = array();
				}
				$attr_arr[$attr['parent_id']]['child'][] = $attr;
			}
		}
		$attr_arr = array_values($attr_arr);

		return $attr_arr;
	}
	public static function pjActionGetQuoteStock($quote_id, $locale_id)
	{
		$os_arr = pjQuoteStockModel::factory()
			->select("t1.*, t2.sku, t3.content AS name,
				(SELECT GROUP_CONCAT(CONCAT_WS('_', `attribute_id`, `attribute_parent_id`))
					FROM `" . pjStockAttributeModel::factory()->getTable() . "`
					WHERE `stock_id` = `t1`.`stock_id`
					LIMIT 1) AS `attr`,
				(SELECT GROUP_CONCAT(CONCAT_WS('.', `extra_id`, `extra_item_id`))
					FROM `" . pjQuoteExtraModel::factory()->getTable() . "`
					WHERE `quote_stock_id` = `t1`.`id`
					LIMIT 1) AS `extra`")
			->join('pjProduct', 't2.id=t1.product_id', 'left outer')
			->join('pjMultiLang', "t3.model='pjProduct' AND t3.foreign_id=t2.id AND t3.field='name' AND t3.locale='$locale_id'", 'left outer')
			->where('t1.quote_id', $quote_id)
			->findAll()
			->getData();

		$product_id = array();
		foreach ($os_arr as $item) {
			$product_id[] = $item['product_id'];
		}

		$extra_arr = pjAppController::pjActionGetExtrasList($product_id, $locale_id);
		$attr_arr = pjAppController::pjActionGetAttr($product_id, $locale_id);

		return compact('os_arr', 'extra_arr', 'attr_arr');
	}
	public static function pjActionGetOrderStock($order_id, $locale_id)
	{
		$os_arr = pjOrderStockModel::factory()
			->select("t1.*, t2.sku, t3.content AS name,
				(SELECT GROUP_CONCAT(CONCAT_WS('_', `attribute_id`, `attribute_parent_id`))
					FROM `" . pjStockAttributeModel::factory()->getTable() . "`
					WHERE `stock_id` = `t1`.`stock_id`
					LIMIT 1) AS `attr`,
				(SELECT GROUP_CONCAT(CONCAT_WS('.', `extra_id`, `extra_item_id`))
					FROM `" . pjOrderExtraModel::factory()->getTable() . "`
					WHERE `order_stock_id` = `t1`.`id`
					LIMIT 1) AS `extra`")
			->join('pjProduct', 't2.id=t1.product_id', 'left outer')
			->join('pjMultiLang', "t3.model='pjProduct' AND t3.foreign_id=t2.id AND t3.field='name' AND t3.locale='$locale_id'", 'left outer')
			->where('t1.order_id', $order_id)
			->findAll()
			->getData();

		$product_id = array();
		foreach ($os_arr as $item) {
			$product_id[] = $item['product_id'];
		}

		$extra_arr = pjAppController::pjActionGetExtrasList($product_id, $locale_id);
		$attr_arr = pjAppController::pjActionGetAttr($product_id, $locale_id);

		return compact('os_arr', 'extra_arr', 'attr_arr');
	}

	public static function pjActionGetProductsString($order_id, $locale_id)
	{
		$result = pjAppController::pjActionGetOrderStock($order_id, $locale_id);
		if (!isset($result['os_arr']) || empty($result['os_arr'])) {
			return '';
		}

		$stack = array();
		foreach ($result['os_arr'] as $item) {
			$stack[] = sprintf("%s x %u", $item['name'], (int) $item['qty']);
			$attrs = array();
			if (isset($item['attr']) && !empty($item['attr'])) {
				$at = array();
				$a = explode(",", $item['attr']);
				foreach ($a as $v) {
					$t = explode("_", $v);
					$at[$t[1]] = $t[0];
				}
				foreach ($at as $attr_parent_id => $attr_id) {
					foreach ($result['attr_arr'] as $attr) {
						if ($attr['id'] == $attr_parent_id) {
							foreach ($attr['child'] as $child) {
								if ($child['id'] == $attr_id) {
									$attrs[] = sprintf('%s: %s', $attr['name'], $child['name']);
									break;
								}
							}
						}
					}
				}
			}
			if (!empty($attrs)) {
				$stack[] = join("; ", $attrs);
			}
			//Extras
			$extras = array();
			if (isset($item['extra']) && !empty($item['extra'])) {
				$a = explode(",", $item['extra']);
				foreach ($a as $eid) {
					if (strpos($eid, ".") === FALSE) {
						//single
						foreach ($result['extra_arr'] as $extra) {
							if ($extra['id'] == $eid) {
								$extras[] = $extra['name'];
								break;
							}
						}
					} else {
						//multi
						list($e_id, $ei_id) = explode(".", $eid);
						foreach ($result['extra_arr'] as $extra) {
							if ($extra['id'] == $e_id && isset($extra['extra_items']) && !empty($extra['extra_items'])) {
								foreach ($extra['extra_items'] as $extra_item) {
									if ($extra_item['id'] == $ei_id) {
										$extras[] = $extra_item['name'];
										break;
									}
								}
								break;
							}
						}
					}
				}
			}
			if (!empty($extras)) {
				$stack[] = join("; ", $extras);
			}
		}

		return join("\n", $stack);
	}

	public static function pjActionCalcPrices($product_id, $extra_arr, $cart_arr, $stocks, $voucher, $option_arr, $tax_id, $from)
	{
		$price = $discount = $tax = $shipping = $insurance = $total = 0;

		foreach ($cart_arr as $cart_item) {
			if ($cart_item['is_cart'] == 1) {

				$qty = isset($cart_item['qty']) ? (int)$cart_item['qty'] : 1;
				$amount = 0;

				if ($from === 'front') {

					$item = !empty($cart_item['key_data'])
						? @unserialize($cart_item['key_data'])
						: [];

					$stock_id = $cart_item['stock_id'] ?? null;

					// 🔒 SAFETY: stock must exist
					if ($stock_id === null || !isset($stocks[$stock_id])) {
						continue;
					}

					$stock = $stocks[$stock_id];

					// 🔒 SAFETY: stock qty check
					if (!empty($item) && empty($item['is_digital'])) {
						if (isset($stock['qty']) && $qty > (int)$stock['qty']) {
							return false;
						}
					}

					$stock_price = isset($stock['price']) ? (float)$stock['price'] : 0;
					$amount = $stock_price * $qty;

					// Extras
					if (isset($item['extra']) && is_array($item['extra'])) {
						foreach ($item['extra'] as $extra) {

							if (strpos($extra, '.') !== false) {
								[$extra_id, $extra_item_id] = explode('.', $extra);

								if (
									isset($extra_arr[$extra_id]['extra_items'][$extra_item_id])
								) {
									$amount += (float)$extra_arr[$extra_id]['extra_items'][$extra_item_id] * $qty;
								}
							} else {
								if (isset($extra_arr[$extra]['price'])) {
									$amount += (float)$extra_arr[$extra]['price'] * $qty;
								}
							}
						}
					}
				} else {

					$amount = $qty * (float)($cart_item['price'] ?? 0);

					$oe_arr = pjOrderExtraModel::factory()
						->where('t1.order_id', $product_id)
						->findAll()
						->getData();

					foreach ($oe_arr as $oe_item) {
						if (
							isset($cart_item['id'], $oe_item['order_stock_id']) &&
							$cart_item['id'] == $oe_item['order_stock_id']
						) {
							$amount += (float)$oe_item['price'] * $qty;
						}
					}
				}

				$price += $amount;

				if ($voucher && ($voucher['voucher_apply'] ?? '') === 'each') {
					$discount += pjUtil::getDiscount(
						$amount,
						$cart_item['product_id'] ?? null,
						$voucher
					);
				}
			}
		}

		// Voucher total
		if ($voucher && ($voucher['voucher_apply'] ?? '') === 'total') {
			if (($voucher['voucher_type'] ?? '') === 'percent') {
				$discount = ($price * (float)$voucher['voucher_discount']) / 100;
			} elseif (($voucher['voucher_type'] ?? '') === 'amount') {
				$discount = (float)$voucher['voucher_discount'];
			}
		}

		// Tax & shipping
		if ((int)$tax_id > 0) {
			$tax_arr = pjTaxModel::factory()->find($tax_id)->getData();

			if (!empty($tax_arr)) {
				$shipping = (float)($tax_arr['shipping'] ?? 0);

				if (
					(float)($tax_arr['free'] ?? 0) > 0 &&
					$price >= (float)$tax_arr['free']
				) {
					$shipping = 0;
				}

				if ((float)($tax_arr['tax'] ?? 0) > 0) {
					$tax = ($price * (float)$tax_arr['tax']) / 100;
				}
			}
		}

		// Insurance
		switch ($option_arr['o_insurance_type'] ?? '') {
			case 'percent':
				$insurance = ($price * (float)$option_arr['o_insurance']) / 100;
				break;
			case 'amount':
				$insurance = (float)$option_arr['o_insurance'];
				break;
			default:
				$insurance = 0;
		}

		$total = $price + $shipping + $tax + $insurance - $discount;

		return compact('price', 'tax', 'shipping', 'insurance', 'discount', 'total');
	}

	protected function pjActionGenerateInvoice($order_id)
	{
		if (!isset($order_id) || (int) $order_id <= 0) {
			return array('status' => 'ERR', 'code' => 400, 'text' => 'ID is not set ot invalid.');
		}
		$arr = pjOrderModel::factory()
			->select('t1.*, t2.email, t2.phone, t2.url')
			->join('pjClient', 't2.id=t1.client_id', 'left outer')
			->find($order_id)->getData();
		if (empty($arr)) {
			return array('status' => 'ERR', 'code' => 404, 'text' => 'Order not found.');
		}

		$stack = pjAppController::pjActionGetOrderStock($arr['id'], $arr['locale_id']);

		$items = array();
		if (isset($stack['os_arr']) && !empty($stack['os_arr'])) {
			$total = 0;
			foreach ($stack['os_arr'] as $i => $item) {
				$desc = array();
				$extra_price = 0;
				if (isset($item['attr']) && !empty($item['attr'])) {
					$at = array();
					$a = explode(",", $item['attr']);
					foreach ($a as $v) {
						$t = explode("_", $v);
						$at[$t[1]] = $t[0];
					}
					foreach ($at as $attr_parent_id => $attr_id) {
						foreach ($stack['attr_arr'] as $attr) {
							if ($attr['id'] == $attr_parent_id) {
								foreach ($attr['child'] as $child) {
									if ($child['id'] == $attr_id) {
										$desc[] = sprintf('%s: %s', $attr['name'], pjSanitize::html($child['name']));
										break;
									}
								}
							}
						}
					}
				}
				//Extras
				if (isset($item['extra']) && !empty($item['extra'])) {
					$a = explode(",", $item['extra']);
					foreach ($a as $eid) {
						if (strpos($eid, ".") === FALSE) {
							//single
							foreach ($stack['extra_arr'] as $extra) {
								if ($extra['id'] == $eid) {
									$desc[] = sprintf('Extra: %s (%s)', $extra['name'], pjCurrency::formatPrice($extra['price']));
									$extra_price += $extra['price'];
									break;
								}
							}
						} else {
							//multi
							list($e_id, $ei_id) = explode(".", $eid);
							foreach ($stack['extra_arr'] as $extra) {
								if ($extra['id'] == $e_id && isset($extra['extra_items']) && !empty($extra['extra_items'])) {
									foreach ($extra['extra_items'] as $extra_item) {
										if ($extra_item['id'] == $ei_id) {
											$desc[] = sprintf('Extra: %s (%s)', $extra_item['name'], pjCurrency::formatPrice($extra_item['price']));
											$extra_price += $extra_item['price'];
											break;
										}
									}
									break;
								}
							}
						}
					}
				}
				$price = $item['price'] + $extra_price;
				$subtotal = $price * (int) $item['qty'];
				$total += $subtotal;

				$items[] = array(
					'name' => $item['name'],
					'description' => join("; ", $desc),
					'qty' => (int) $item['qty'],
					'unit_price' => number_format($price, 2, ".", ""),
					'amount' => number_format($subtotal, 2, ".", "")
				);
			}
			$items[] = array(
				'name' => __('order_insurance', true),
				'description' => NULL,
				'qty' => 1,
				'unit_price' => $arr['insurance'],
				'amount' => $arr['insurance']
			);
			$items[] = array(
				'name' => __('order_shipping', true),
				'description' => NULL,
				'qty' => 1,
				'unit_price' => $arr['shipping'],
				'amount' => $arr['shipping']
			);
		} else {
			$items[] = array(
				'name' => 'Order payment',
				'description' => "",
				'qty' => 1,
				'unit_price' => $arr['total'],
				'amount' => $arr['total']
			);
		}

		$map = array(
			'completed' => 'paid',
			'cancelled' => 'cancelled',
			'new' => 'not_paid',
			'pending' => 'not_paid'
		);

		$response = $this->requestAction(
			array(
				'controller' => 'pjInvoice',
				'action' => 'pjActionCreate',
				'params' => array(
					'key' => md5($this->option_arr['private_key'] . PJ_SALT),
					'uuid' => pjUtil::uuid(),
					'order_id' => $arr['uuid'],
					'foreign_id' => $this->getForeignId(),
					'issue_date' => ':CURDATE()',
					'due_date' => ':CURDATE()',
					'created' => ':NOW()',
					//'modified' => ':NULL',
					'status' => @$map[$arr['status']],
					'subtotal' => $arr['price'] + $arr['insurance'] + $arr['shipping'],
					'discount' => $arr['discount'],
					'tax' => $arr['tax'],
					'shipping' => $arr['shipping'],
					'total' => $arr['total'],
					'paid_deposit' => 0,
					'amount_due' => 0,
					'currency' => $this->option_arr['o_currency'],
					'notes' => $arr['notes'],
					'b_billing_address' => $arr['b_address_1'],
					'b_name' => $arr['b_name'],
					'b_address' => $arr['b_address_1'],
					'b_street_address' => $arr['b_address_2'],
					'b_city' => $arr['b_city'],
					'b_state' => $arr['b_state'],
					'b_zip' => $arr['b_zip'],
					'b_phone' => $arr['phone'],
					'b_email' => $arr['email'],
					'b_url' => $arr['url'],
					's_shipping_address' => (int) $arr['same_as'] === 1 ? $arr['b_address_1'] : $arr['s_address_1'],
					's_name' => (int) $arr['same_as'] === 1 ? $arr['b_name'] : $arr['s_name'],
					's_address' => (int) $arr['same_as'] === 1 ? $arr['b_address_1'] : $arr['s_address_1'],
					's_street_address' => (int) $arr['same_as'] === 1 ? $arr['b_address_2'] : $arr['s_address_2'],
					's_city' => (int) $arr['same_as'] === 1 ? $arr['b_city'] : $arr['s_city'],
					's_state' => (int) $arr['same_as'] === 1 ? $arr['b_state'] : $arr['s_state'],
					's_zip' => (int) $arr['same_as'] === 1 ? $arr['b_zip'] : $arr['s_zip'],
					's_phone' => $arr['phone'],
					's_email' => $arr['email'],
					's_url' => $arr['url'],
					'items' => $items
				)
			),
			array('return')
		);

		return $response;
	}

	public function getModel($key)
	{
		if (array_key_exists($key, $this->models)) {
			return $this->models[$key];
		}

		return false;
	}

	public function setModel($key, $value)
	{
		$this->models[$key] = $value;

		return true;
	}

	public function getLayoutRange()
	{
		return $this->layoutRange;
	}

	public static function pjActionGetSubjectMessage($notification, $locale_id)
	{
		$variant = $notification['variant'] == 'confirmation' ? 'confirm' : $notification['variant'];
		$field = $variant . '_tokens_' . $notification['recipient'];
		$pjMultiLangModel = pjMultiLangModel::factory();
		$lang_message = $pjMultiLangModel
			->reset()
			->select('t1.*')
			->where('t1.foreign_id', $notification['id'])
			->where('t1.model', 'pjNotification')
			->where('t1.locale', $locale_id)
			->where('t1.field', $field)
			->limit(0, 1)
			->findAll()
			->getData();
		$field = $variant . '_subject_' . $notification['recipient'];
		$lang_subject = $pjMultiLangModel
			->reset()
			->select('t1.*')
			->where('t1.foreign_id',  $notification['id'])
			->where('t1.model', 'pjNotification')
			->where('t1.locale', $locale_id)
			->where('t1.field', $field)
			->limit(0, 1)
			->findAll()
			->getData();
		return compact('lang_message', 'lang_subject');
	}

	// public static function sendFlexMail($email, $subject, $message, $option_arr)
	// {

	// 	$curl = curl_init();
	// 	// 		$username = "70706";
	// 	// 		$password = "56f4c52c9e6b9e14443adc66b59416a559237a33c4e17f6b9828eb8cf2602302";
	// 	if (isset($option_arr['o_sender_flex_email_user_id'])) {
	// 		$username = $option_arr['o_sender_flex_email_user_id'];
	// 		$password = $option_arr['o_sender_flex_email_api_key'];
	// 	} else {
	// 		$option_arr_new = [];

	// 		foreach ($option_arr as $option) {
	// 			$option_arr_new[$option['key']] = $option['value'];
	// 		}
	// 		$username = $option_arr_new['o_sender_flex_email_user_id'];
	// 		$password = $option_arr_new['o_sender_flex_email_api_key'];

	// 	}


	// 	curl_setopt($curl, CURLOPT_USERPWD, $username . ":" . $password);
	// 	curl_setopt_array($curl, [
	// 		CURLOPT_URL            => 'https://email-api.flexmail.eu/messages',
	// 		CURLOPT_RETURNTRANSFER => true,
	// 		CURLOPT_ENCODING       => '',
	// 		CURLOPT_MAXREDIRS      => 10,
	// 		CURLOPT_TIMEOUT        => 0,
	// 		CURLOPT_FOLLOWLOCATION => true,
	// 		CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
	// 		CURLOPT_CUSTOMREQUEST  => 'POST',

	// 		CURLOPT_SSL_VERIFYPEER => false,
	// 		CURLOPT_SSL_VERIFYHOST => false,
	// 	]);
	// 	curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode([
	// 		"recipient" => [
	// 			"address" => [
	// 				"email_address" => $email,
	// 				//  "name" => $name
	// 			],
	// 		],
	// 		"from"      => [
	// 			// "email_address" => "info@easyexpo.nl",
	// 			// "name" => "Easyexpo"
	// 			"email_address" => $option_arr['o_flexmail_sender_email'],
	// 			"name"          => $option_arr['o_flexmail_sender_name'],
	// 		],
	// 		"subject"   => $subject,
	// 		"content"   => [
	// 			"html" => $message,
	// 		],
	// 	]));

	// 	$response = curl_exec($curl);
	// 	// echo "<pre>"; print_r($password);
	// 	curl_close($curl);

	// 	return $response;
	// }
	public static function sendFlexMail($email, $subject, $message, $option_arr)
	{
		$curl = curl_init();

		// If array is not in key=>value format, convert it
		if (!isset($option_arr['o_sender_flex_email_user_id']) || !isset($option_arr['o_sender_flex_email_api_key'])) {
			$option_arr_new = [];

			foreach ($option_arr as $option) {
				if (isset($option['key']) && isset($option['value'])) {
					$option_arr_new[$option['key']] = $option['value'];
				}
			}

			$option_arr = $option_arr_new;
		}

		$username = $option_arr['o_sender_flex_email_user_id'];
		$password = $option_arr['o_sender_flex_email_api_key'];
		
		curl_setopt($curl, CURLOPT_USERPWD, $username . ":" . $password);

		curl_setopt_array($curl, [
			CURLOPT_URL            => 'https://email-api.flexmail.eu/messages',
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING       => '',
			CURLOPT_MAXREDIRS      => 10,
			CURLOPT_TIMEOUT        => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST  => 'POST',

			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_SSL_VERIFYHOST => false,

			CURLOPT_HTTPHEADER => [
				'Content-Type: application/json'
			]
		]);

		curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode([
			"recipient" => [
				"address" => [
					"email_address" => $email
				]
			],
			"from" => [
				"email_address" => $option_arr['o_flexmail_sender_email'],
				"name" => $option_arr['o_flexmail_sender_name'],
			],
			"subject" => $subject,
			"content" => [
				"html" => $message,
			],
		]));

		$response = curl_exec($curl);

		curl_close($curl);

		return $response;
	}
}
