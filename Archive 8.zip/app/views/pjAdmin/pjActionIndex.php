<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-lg-4 col-sm-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <span class="label label-primary pull-right"><?php __('dash_today');?></span>

                    <h5><?php __('dash_orders');?></h5>
                </div>

                <div class="ibox-content">
                    <div class="row m-t-md m-b-sm">
                        <div class="col-xs-12">
                            <p class="h1 no-margins"><?php echo (int) @$tpl['info_arr'][0]['orders'];?> / <?php echo pjCurrency::formatPrice(@$tpl['info_arr'][0]['amount'])?></p>
                            <small class="text-info"><?php echo (int) @$tpl['info_arr'][0]['orders'] != 1 ? __('dashboard_orders_today', true, false) : __('dashboard_order_today', true, false); ?></small>        
                        </div><!-- /.col-xs-6 -->

                    </div><!-- /.row -->
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-sm-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <span class="label label-primary pull-right"><?php __('dash_today');?></span>

                    <h5><?php __('dash_products');?></h5>
                </div>

                <div class="ibox-content">
                    <div class="row m-t-md m-b-sm">
                        <div class="col-xs-12">
                            <p class="h1 no-margins"><?php echo (int) @$tpl['info_arr'][0]['products'];?></p>
                            <small class="text-info"><?php (int) @$tpl['info_arr'][0]['products'] !== 1 ? __('lblProductsOrderedToday') : __('lblProductOrderedToday'); ?></small>        
                        </div><!-- /.col-xs-6 -->
                    </div><!-- /.row -->
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-sm-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5><?php __('dash_total');?></h5>
                </div>

                <div class="ibox-content">
                    <div class="row m-t-md m-b-sm">
                        <div class="col-xs-12">
                            <p class="h1 no-margins"><?php echo (int) @$tpl['cnt_orders'];?> / <?php echo pjCurrency::formatPrice($tpl['amount']);?></p>
                            <small class="text-info"><?php (int) @$tpl['cnt_orders'] !== 1 ? __('lblTotalOrders') : __('lblTotalOrder'); ?></small>        
                        </div><!-- /.col-xs-6 -->
                    </div><!-- /.row -->
                </div>
            </div>
        </div>
    </div><!-- /.row -->
	<?php
	$order_statuses = __('order_statuses', true);
	$has_access_update_client = pjAuth::factory('pjAdminClients', 'pjActionUpdate')->hasAccess();
	$has_access_update_order = pjAuth::factory('pjAdminOrders', 'pjActionUpdate')->hasAccess();
	?>
    <div class="row">
        <div class="col-md-6">
            <div class="ibox float-e-margins">
                <div class="ibox-content ibox-heading clearfix">
                    <div class="pull-left">
                        <h3><?php __('dashboard_last_orders');?></h3>
                    </div><!-- /.pull-left -->
					<?php if (pjAuth::factory('pjAdminOrders', 'pjActionIndex')->hasAccess()) { ?>
	                    <div class="pull-right m-t-md">
	                    	<a class="btn btn-primary btn-sm btn-outline m-n" href="<?php echo $_SERVER['PHP_SELF']; ?>?controller=pjAdminOrders&amp;action=pjActionIndex"><?php __('lblViewAll');?></a>
	                    </div><!-- /.pull-right -->
                    <?php } ?>
                </div>
				
                <div class="ibox-content inspinia-timeline">
                	<?php
                	if(!empty($tpl['order_arr']))
                	{
                	    foreach($tpl['order_arr'] as $v)
                	    {
                	        $date_time = date($tpl['option_arr']['o_date_format'], strtotime($v['created'])) . ',<br/>' . date($tpl['option_arr']['o_time_format'], strtotime($v['created']));
                	        ?>
                	        <div class="timeline-item">
                                <div class="row">
                                    <div class="col-xs-3 date">
                                        <i class="fa fa-clock-o"></i>
                                        <?php echo $date_time;?>
                                    </div>
        
                                    <div class="col-xs-7 content">
                                    	<p class="m-b-xs"><strong>
                                    		<?php if ($has_access_update_client) { ?>
                                    			<a href="<?php echo $_SERVER['PHP_SELF']; ?>?controller=pjAdminClients&amp;action=pjActionUpdate&amp;id=<?php echo $v['client_id']?>"><?php echo pjSanitize::html($v['client_name']);?></a>
                                    		<?php } else { 
                                    			echo pjSanitize::html($v['client_name']);
                                    		} ?>
                                    	</strong></p>
                                        <p class="m-n"><?php __('dashboard_order_id')?>: <em>
                                        	<?php if ($has_access_update_order) { ?>
                                        		<a href="<?php echo $_SERVER['PHP_SELF']; ?>?controller=pjAdminOrders&amp;action=pjActionUpdate&amp;id=<?php echo $v['id']?>"><?php echo pjSanitize::html($v['uuid']);?></a>
                                        	<?php } else {
                                        		echo pjSanitize::html($v['uuid']);
                                        	} ?>
                                        </em></p>
                                        <p class="m-n"><?php __('dashboard_total')?>: <em><?php echo pjCurrency::formatPrice($v['total']);?></em></p>
                                        <p class="m-n"><?php __('dashboard_payment')?>: <em><?php echo @$tpl['payment_titles'][$v['payment_method']];?></em></p>
                                    </div>
                                    
                                    <div class="badge bg-<?php echo $v['status'];?> b-r-sm pull-right m-t-md m-r-sm"><?php echo $order_statuses[$v['status']];?></div>
                                </div>
                            </div>
                	        <?php
                	    }
                	}else{
                	    ?>
                	    <div class="row">
                            <div class="col-xs-12">
                                <p class="m-b-xs"><?php __('lblDashNoOrdersFound');?></p>
                            </div>
                        </div>
                	    <?php
                	}
                	?>
                </div>
            </div>
        </div><!-- /.col-lg-4 -->

        <div class="col-md-6">
            <div class="ibox float-e-margins">
                <div class="ibox-content ibox-heading clearfix">
                    <div class="pull-left">
                        <h3><?php __('lblDashProductsOrderedToday');?></h3>
                    </div><!-- /.pull-left -->
					<?php if (pjAuth::factory('pjAdminProducts', 'pjActionIndex')->hasAccess()) { ?>
	                    <div class="pull-right m-t-md">
	                    	<a class="btn btn-primary btn-sm btn-outline m-n" href="<?php echo $_SERVER['PHP_SELF']; ?>?controller=pjAdminProducts&amp;action=pjActionIndex"><?php __('lblViewAll');?></a>
	                    </div><!-- /.pull-right -->
                    <?php } ?>
                </div>

                <div class="ibox-content inspinia-timeline">
                    <?php
                	if(!empty($tpl['product_arr']))
                	{
                		$idx = 0;
                	    foreach ($tpl['product_arr'] as $product_id => $orders)
                	    {
	                	    $order_arr = array();
							foreach($orders as $k => $v)
							{
								if (pjAuth::factory('pjAdminProducts', 'pjActionIndex')->hasAccess()) {
									$order_arr[] = '<a href="'.$_SERVER['PHP_SELF'].'?controller=pjAdminOrders&amp;action=pjActionUpdate&amp;id='.$v['order_id'].'">'.$v['uuid'].'</a>';
								} else {
									$order_arr[] = $v['uuid'];
								}
							}
                	        ?>
                	        <div class="content clearfix">
								<p class="m-n">
									<?php echo pjSanitize::html($orders[0]['name']); ?>
								</p>
								<p class="m-n">
									<?php __('lblDashOrders');?>: <?php echo join('; ', $order_arr);?>
								</p>
							</div>
							<?php if ($idx < count($tpl['product_arr'])-1) { ?>
								<div class="hr-line-dashed"></div>
                	        	<?php
							}
                	        $idx++;
                	    }
                	}else{
                	    ?>
                	    <div class="row">
                            <div class="col-xs-12">
                                <p class="m-b-xs"><?php __('lblDashNoProductsOrderedToday');?></p>
                            </div>
                        </div>
                	    <?php
                	}
                	?>
                </div>
            </div>
        </div><!-- /.col-lg-8 -->
    </div><!-- /.row -->
</div><!-- /.wrapper wrapper-content -->